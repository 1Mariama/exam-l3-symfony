<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20241219181732 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE classe (id SERIAL NOT NULL, niveau_id_id INT NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_8F87BF969A236C31 ON classe (niveau_id_id)');
        $this->addSql('CREATE TABLE cour_classes (id SERIAL NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE cour_classes_cours (cour_classes_id INT NOT NULL, cours_id INT NOT NULL, PRIMARY KEY(cour_classes_id, cours_id))');
        $this->addSql('CREATE INDEX IDX_FD9B7E5DA79DDDEE ON cour_classes_cours (cour_classes_id)');
        $this->addSql('CREATE INDEX IDX_FD9B7E5D7ECF78B0 ON cour_classes_cours (cours_id)');
        $this->addSql('CREATE TABLE cour_classes_classe (cour_classes_id INT NOT NULL, classe_id INT NOT NULL, PRIMARY KEY(cour_classes_id, classe_id))');
        $this->addSql('CREATE INDEX IDX_63E41C42A79DDDEE ON cour_classes_classe (cour_classes_id)');
        $this->addSql('CREATE INDEX IDX_63E41C428F5EA509 ON cour_classes_classe (classe_id)');
        $this->addSql('CREATE TABLE cours (id SERIAL NOT NULL, professeur_id_id INT DEFAULT NULL, module_id_id INT NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_FDCA8C9CEE1AF529 ON cours (professeur_id_id)');
        $this->addSql('CREATE INDEX IDX_FDCA8C9C7648EE39 ON cours (module_id_id)');
        $this->addSql('CREATE TABLE etudiant (id SERIAL NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE inscription (id SERIAL NOT NULL, etudiant_id_id INT NOT NULL, classe_id_id INT NOT NULL, annee_scolaire DATE NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_5E90F6D67EB24B ON inscription (etudiant_id_id)');
        $this->addSql('CREATE INDEX IDX_5E90F6D63633CA6F ON inscription (classe_id_id)');
        $this->addSql('CREATE TABLE module (id SERIAL NOT NULL, nom VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE niveaux (id SERIAL NOT NULL, nom VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE professeur (id SERIAL NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE TABLE session (id SERIAL NOT NULL, cours_id_id INT NOT NULL, date DATE NOT NULL, heure_fin TIME(0) WITHOUT TIME ZONE NOT NULL, heure_debut TIME(0) WITHOUT TIME ZONE NOT NULL, salle VARCHAR(25) DEFAULT NULL, PRIMARY KEY(id))');
        $this->addSql('CREATE INDEX IDX_D044D5D44F221781 ON session (cours_id_id)');
        $this->addSql('ALTER TABLE classe ADD CONSTRAINT FK_8F87BF969A236C31 FOREIGN KEY (niveau_id_id) REFERENCES niveaux (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cour_classes_cours ADD CONSTRAINT FK_FD9B7E5DA79DDDEE FOREIGN KEY (cour_classes_id) REFERENCES cour_classes (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cour_classes_cours ADD CONSTRAINT FK_FD9B7E5D7ECF78B0 FOREIGN KEY (cours_id) REFERENCES cours (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cour_classes_classe ADD CONSTRAINT FK_63E41C42A79DDDEE FOREIGN KEY (cour_classes_id) REFERENCES cour_classes (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cour_classes_classe ADD CONSTRAINT FK_63E41C428F5EA509 FOREIGN KEY (classe_id) REFERENCES classe (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cours ADD CONSTRAINT FK_FDCA8C9CEE1AF529 FOREIGN KEY (professeur_id_id) REFERENCES professeur (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE cours ADD CONSTRAINT FK_FDCA8C9C7648EE39 FOREIGN KEY (module_id_id) REFERENCES module (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE inscription ADD CONSTRAINT FK_5E90F6D67EB24B FOREIGN KEY (etudiant_id_id) REFERENCES etudiant (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE inscription ADD CONSTRAINT FK_5E90F6D63633CA6F FOREIGN KEY (classe_id_id) REFERENCES classe (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('ALTER TABLE session ADD CONSTRAINT FK_D044D5D44F221781 FOREIGN KEY (cours_id_id) REFERENCES cours (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SCHEMA public');
        $this->addSql('ALTER TABLE classe DROP CONSTRAINT FK_8F87BF969A236C31');
        $this->addSql('ALTER TABLE cour_classes_cours DROP CONSTRAINT FK_FD9B7E5DA79DDDEE');
        $this->addSql('ALTER TABLE cour_classes_cours DROP CONSTRAINT FK_FD9B7E5D7ECF78B0');
        $this->addSql('ALTER TABLE cour_classes_classe DROP CONSTRAINT FK_63E41C42A79DDDEE');
        $this->addSql('ALTER TABLE cour_classes_classe DROP CONSTRAINT FK_63E41C428F5EA509');
        $this->addSql('ALTER TABLE cours DROP CONSTRAINT FK_FDCA8C9CEE1AF529');
        $this->addSql('ALTER TABLE cours DROP CONSTRAINT FK_FDCA8C9C7648EE39');
        $this->addSql('ALTER TABLE inscription DROP CONSTRAINT FK_5E90F6D67EB24B');
        $this->addSql('ALTER TABLE inscription DROP CONSTRAINT FK_5E90F6D63633CA6F');
        $this->addSql('ALTER TABLE session DROP CONSTRAINT FK_D044D5D44F221781');
        $this->addSql('DROP TABLE classe');
        $this->addSql('DROP TABLE cour_classes');
        $this->addSql('DROP TABLE cour_classes_cours');
        $this->addSql('DROP TABLE cour_classes_classe');
        $this->addSql('DROP TABLE cours');
        $this->addSql('DROP TABLE etudiant');
        $this->addSql('DROP TABLE inscription');
        $this->addSql('DROP TABLE module');
        $this->addSql('DROP TABLE niveaux');
        $this->addSql('DROP TABLE professeur');
        $this->addSql('DROP TABLE session');
    }
}
