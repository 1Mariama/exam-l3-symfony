<?php

namespace App\Controller;

use App\Entity\Classe;
use App\Repository\ClasseRepository;
use App\Repository\InscriptionRepository;
use App\Repository\CourClassesRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class ClasseController extends AbstractController
{
    #[Route('/api/classes', name: 'app_cour_classes', methods:['GET'])]
    public function index(ClasseRepository $classeRepository): JsonResponse
    {
        $classes = $classeRepository->findAll();

        $data = [];
        foreach ($classes as $classe) {
            $data[] = [
                'id' => $classe->getId(),
                'niveau' => $classe->getNiveau()->getNom(), // Exemple d'accès au niveau
                'inscriptions' => count($classe->getInscriptions()), // Exemple de nombre d'inscriptions
            ];
        }

        return $this->json($data);
    }

    #[Route('/api/classes', name: 'app_cour_classes', methods:['GET'])]
    public function showInscriptions(int $id, InscriptionRepository $inscriptionRepository): JsonResponse
    {
        $inscriptions = $inscriptionRepository->findBy(['classe' => $id]);

        if (!$inscriptions) {
            return $this->json([
                'message' => 'Aucune inscription trouvée pour cette classe.'
            ], 404);
        }

        $data = [];
        foreach ($inscriptions as $inscription) {
            $data[] = [
                'id' => $inscription->getId(),
                'etudiant' => $inscription->getEtudiant()->getNom() . ' ' . $inscription->getEtudiant()->getPrenom(),
                'annee_scolaire' => $inscription->getAnneeScolaire(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Afficher les cours associés à une classe spécifique
     * 
     * @Route("/classe/{id}/cours", name="classe_cours", methods={"GET"})
     */
    public function showCours(int $id, CourClassesRepository $courClassesRepository): JsonResponse
    {
        $courClasses = $courClassesRepository->findByClasse($id);

        if (!$courClasses) {
            return $this->json([
                'message' => 'Aucun cours trouvé pour cette classe.'
            ], 404);
        }

        $data = [];
        foreach ($courClasses as $courClass) {
            $data[] = [
                'id' => $courClass->getCours()->getId(),
                'module' => $courClass->getCours()->getModule()->getNom(),
                'professeur' => $courClass->getCours()->getProfesseur()->getNom(),
                'sessions' => count($courClass->getCours()->getSessions()), // Nombre de sessions pour ce cours
            ];
        }

        return $this->json($data);
    }
}