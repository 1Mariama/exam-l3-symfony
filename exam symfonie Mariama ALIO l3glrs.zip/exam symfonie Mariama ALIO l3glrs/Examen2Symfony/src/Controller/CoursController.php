<?php

namespace App\Controller;

use App\Entity\Cours;
use App\Repository\CoursRepository;
use App\Repository\ProfesseurRepository;
use App\Repository\ModuleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class CoursController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher tous les cours
     * 
     * @Route("/cours", name="app_cours_index", methods={"GET"})
     */
    public function index(CoursRepository $coursRepository): JsonResponse
    {
        $cours = $coursRepository->findAll();

        $data = [];
        foreach ($cours as $coursItem) {
            $data[] = [
                'id' => $coursItem->getId(),
                'professeur' => $coursItem->getProfesseurId() ? $coursItem->getProfesseurId()->getNom() : null,
                'module' => $coursItem->getModuleId() ? $coursItem->getModuleId()->getNom() : null,
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer un nouveau cours
     * 
     * @Route("/cours", name="create_cours", methods={"POST"})
     */
    public function create(Request $request, ProfesseurRepository $professeurRepository, ModuleRepository $moduleRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que les données sont valides
        if (!isset($data['professeur_id']) || !isset($data['module_id'])) {
            return $this->json(['message' => 'Professeur et Module sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $professeur = $professeurRepository->find($data['professeur_id']);
        $module = $moduleRepository->find($data['module_id']);

        if (!$professeur || !$module) {
            return $this->json(['message' => 'Professeur ou Module non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $cours = new Cours();
        $cours->setProfesseurId($professeur);
        $cours->setModuleId($module);

        $this->entityManager->persist($cours);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Cours créé avec succès.',
            'id' => $cours->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour un cours existant
     * 
     * @Route("/cours/{id}", name="update_cours", methods={"PUT"})
     */
    public function update(int $id, Request $request, CoursRepository $coursRepository, ProfesseurRepository $professeurRepository, ModuleRepository $moduleRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $cours = $coursRepository->find($id);

        if (!$cours) {
            return $this->json(['message' => 'Cours non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        // Vérifier que les données sont valides
        if (isset($data['professeur_id'])) {
            $professeur = $professeurRepository->find($data['professeur_id']);
            if ($professeur) {
                $cours->setProfesseurId($professeur);
            }
        }

        if (isset($data['module_id'])) {
            $module = $moduleRepository->find($data['module_id']);
            if ($module) {
                $cours->setModuleId($module);
            }
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Cours mis à jour avec succès.',
            'id' => $cours->getId()
        ]);
    }

    /**
     * Supprimer un cours
     * 
     * @Route("/cours/{id}", name="delete_cours", methods={"DELETE"})
     */
    public function delete(int $id, CoursRepository $coursRepository): JsonResponse
    {
        $cours = $coursRepository->find($id);

        if (!$cours) {
            return $this->json(['message' => 'Cours non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($cours);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Cours supprimé avec succès.'
        ]);
    }
}