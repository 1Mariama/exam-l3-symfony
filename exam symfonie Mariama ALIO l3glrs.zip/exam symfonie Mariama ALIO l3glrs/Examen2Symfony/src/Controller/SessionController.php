<?php

namespace App\Controller;

use App\Entity\Session;
use App\Repository\SessionRepository;
use App\Repository\CoursRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class SessionController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    
    #[Route("api/sessions", name:"app_session_index", methods:["GET"])]
    public function index(SessionRepository $sessionRepository): JsonResponse
    {
        $sessions = $sessionRepository->findAll();

        $data = [];
        foreach ($sessions as $session) {
            $data[] = [
                'id' => $session->getId(),
                'date' => $session->getDate()->format('Y-m-d'),
                'heureDebut' => $session->getHeureDebut()->format('H:i'),
                'heureFin' => $session->getHeureFin()->format('H:i'),
                'salle' => $session->getSalle(),
                'cours' => $session->getCoursId()->getId(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer une session
     * 
     * @Route("/sessions", name="create_session", methods={"POST"})
     */
    public function create(Request $request, CoursRepository $coursRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que les données nécessaires sont présentes
        if (!isset($data['date'], $data['heureDebut'], $data['heureFin'], $data['cours_id'])) {
            return $this->json(['message' => 'Les champs date, heureDebut, heureFin et cours_id sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $cours = $coursRepository->find($data['cours_id']);
        if (!$cours) {
            return $this->json(['message' => 'Cours non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $session = new Session();
        $session->setDate(new \DateTime($data['date']));
        $session->setHeureDebut(new \DateTime($data['heureDebut']));
        $session->setHeureFin(new \DateTime($data['heureFin']));
        $session->setSalle($data['salle'] ?? null);
        $session->setCoursId($cours);

        $this->entityManager->persist($session);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Session créée avec succès.',
            'id' => $session->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour une session existante
     * 
     * @Route("/sessions/{id}", name="update_session", methods={"PUT"})
     */
    public function update(int $id, Request $request, SessionRepository $sessionRepository, CoursRepository $coursRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $session = $sessionRepository->find($id);

        if (!$session) {
            return $this->json(['message' => 'Session non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour les données de la session
        if (isset($data['date'])) {
            $session->setDate(new \DateTime($data['date']));
        }

        if (isset($data['heureDebut'])) {
            $session->setHeureDebut(new \DateTime($data['heureDebut']));
        }

        if (isset($data['heureFin'])) {
            $session->setHeureFin(new \DateTime($data['heureFin']));
        }

        if (isset($data['salle'])) {
            $session->setSalle($data['salle']);
        }

        if (isset($data['cours_id'])) {
            $cours = $coursRepository->find($data['cours_id']);
            if (!$cours) {
                return $this->json(['message' => 'Cours non trouvé.'], Response::HTTP_NOT_FOUND);
            }
            $session->setCoursId($cours);
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Session mise à jour avec succès.',
            'id' => $session->getId()
        ]);
    }

    /**
     * Supprimer une session
     * 
     * @Route("/sessions/{id}", name="delete_session", methods={"DELETE"})
     */
    public function delete(int $id, SessionRepository $sessionRepository): JsonResponse
    {
        $session = $sessionRepository->find($id);

        if (!$session) {
            return $this->json(['message' => 'Session non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($session);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Session supprimée avec succès.'
        ]);
    }
}