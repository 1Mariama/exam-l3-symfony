<?php

namespace App\Controller;

use App\Entity\Etudiant;
use App\Repository\EtudiantRepository;
use App\Repository\InscriptionRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class EtudiantController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher tous les étudiants
     * 
     * @Route("/etudiant", name="app_etudiant_index", methods={"GET"})
     */
    public function index(EtudiantRepository $etudiantRepository): JsonResponse
    {
        $etudiants = $etudiantRepository->findAll();

        $data = [];
        foreach ($etudiants as $etudiant) {
            $data[] = [
                'id' => $etudiant->getId(),
                'nom' => $etudiant->getNom(),
                'prenom' => $etudiant->getPrenom(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer un nouvel étudiant
     * 
     * @Route("/etudiant", name="create_etudiant", methods={"POST"})
     */
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que les données sont valides
        if (!isset($data['nom']) || !isset($data['prenom'])) {
            return $this->json(['message' => 'Nom et prénom sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $etudiant = new Etudiant();
        $etudiant->setNom($data['nom']);
        $etudiant->setPrenom($data['prenom']);

        $this->entityManager->persist($etudiant);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Étudiant créé avec succès.',
            'id' => $etudiant->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour un étudiant existant
     * 
     * @Route("/etudiant/{id}", name="update_etudiant", methods={"PUT"})
     */
    public function update(int $id, Request $request, EtudiantRepository $etudiantRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $etudiant = $etudiantRepository->find($id);

        if (!$etudiant) {
            return $this->json(['message' => 'Étudiant non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour les informations de l'étudiant
        if (isset($data['nom'])) {
            $etudiant->setNom($data['nom']);
        }

        if (isset($data['prenom'])) {
            $etudiant->setPrenom($data['prenom']);
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Étudiant mis à jour avec succès.',
            'id' => $etudiant->getId()
        ]);
    }

    /**
     * Supprimer un étudiant
     * 
     * @Route("/etudiant/{id}", name="delete_etudiant", methods={"DELETE"})
     */
    public function delete(int $id, EtudiantRepository $etudiantRepository): JsonResponse
    {
        $etudiant = $etudiantRepository->find($id);

        if (!$etudiant) {
            return $this->json(['message' => 'Étudiant non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($etudiant);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Étudiant supprimé avec succès.'
        ]);
    }
}