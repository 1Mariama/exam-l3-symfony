<?php

namespace App\Controller;

use App\Entity\Inscription;
use App\Repository\InscriptionRepository;
use App\Repository\EtudiantRepository;
use App\Repository\ClasseRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class InscriptionController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher toutes les inscriptions
     * 
     * @Route("/inscription", name="app_inscription_index", methods={"GET"})
     */
    public function index(InscriptionRepository $inscriptionRepository): JsonResponse
    {
        $inscriptions = $inscriptionRepository->findAll();

        $data = [];
        foreach ($inscriptions as $inscription) {
            $data[] = [
                'id' => $inscription->getId(),
                'etudiant' => $inscription->getEtudiantId()->getNom() . ' ' . $inscription->getEtudiantId()->getPrenom(),
                'classe' => $inscription->getClasseId()->getId(),
                'annee_scolaire' => $inscription->getAnneeScolaire()->format('Y'),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer une inscription pour un étudiant
     * 
     * @Route("/inscription", name="create_inscription", methods={"POST"})
     */
    public function create(Request $request, EtudiantRepository $etudiantRepository, ClasseRepository $classeRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que les données sont valides
        if (!isset($data['etudiant_id']) || !isset($data['classe_id']) || !isset($data['annee_scolaire'])) {
            return $this->json(['message' => 'Étudiant, classe et année scolaire sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $etudiant = $etudiantRepository->find($data['etudiant_id']);
        $classe = $classeRepository->find($data['classe_id']);

        if (!$etudiant || !$classe) {
            return $this->json(['message' => 'Étudiant ou classe non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $inscription = new Inscription();
        $inscription->setEtudiantId($etudiant);
        $inscription->setClasseId($classe);
        $inscription->setAnneeScolaire(new \DateTime($data['annee_scolaire']));

        $this->entityManager->persist($inscription);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Inscription créée avec succès.',
            'id' => $inscription->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour une inscription existante
     * 
     * @Route("/inscription/{id}", name="update_inscription", methods={"PUT"})
     */
    public function update(int $id, Request $request, InscriptionRepository $inscriptionRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $inscription = $inscriptionRepository->find($id);

        if (!$inscription) {
            return $this->json(['message' => 'Inscription non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour les informations de l'inscription
        if (isset($data['etudiant_id'])) {
            $inscription->setEtudiantId($data['etudiant_id']);
        }

        if (isset($data['classe_id'])) {
            $inscription->setClasseId($data['classe_id']);
        }

        if (isset($data['annee_scolaire'])) {
            $inscription->setAnneeScolaire(new \DateTime($data['annee_scolaire']));
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Inscription mise à jour avec succès.',
            'id' => $inscription->getId()
        ]);
    }

    /**
     * Supprimer une inscription
     * 
     * @Route("/inscription/{id}", name="delete_inscription", methods={"DELETE"})
     */
    public function delete(int $id, InscriptionRepository $inscriptionRepository): JsonResponse
    {
        $inscription = $inscriptionRepository->find($id);

        if (!$inscription) {
            return $this->json(['message' => 'Inscription non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($inscription);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Inscription supprimée avec succès.'
        ]);
    }
}