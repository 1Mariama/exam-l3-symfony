<?php

namespace App\Controller;

use App\Entity\Professeur;
use App\Repository\ProfesseurRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class ProfesseurController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher tous les professeurs
     * 
     * @Route("/professeurs", name="app_professeur_index", methods={"GET"})
     */
    public function index(ProfesseurRepository $professeurRepository): JsonResponse
    {
        $professeurs = $professeurRepository->findAll();

        $data = [];
        foreach ($professeurs as $professeur) {
            $data[] = [
                'id' => $professeur->getId(),
                'nom' => $professeur->getNom(),
                'prenom' => $professeur->getPrenom(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer un professeur
     * 
     * @Route("/professeurs", name="create_professeur", methods={"POST"})
     */
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que le nom et le prénom du professeur sont fournis
        if (!isset($data['nom']) || !isset($data['prenom'])) {
            return $this->json(['message' => 'Le nom et le prénom du professeur sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $professeur = new Professeur();
        $professeur->setNom($data['nom']);
        $professeur->setPrenom($data['prenom']);

        $this->entityManager->persist($professeur);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Professeur créé avec succès.',
            'id' => $professeur->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour un professeur existant
     * 
     * @Route("/professeurs/{id}", name="update_professeur", methods={"PUT"})
     */
    public function update(int $id, Request $request, ProfesseurRepository $professeurRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $professeur = $professeurRepository->find($id);

        if (!$professeur) {
            return $this->json(['message' => 'Professeur non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour le nom et le prénom du professeur
        if (isset($data['nom'])) {
            $professeur->setNom($data['nom']);
        }

        if (isset($data['prenom'])) {
            $professeur->setPrenom($data['prenom']);
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Professeur mis à jour avec succès.',
            'id' => $professeur->getId()
        ]);
    }

    /**
     * Supprimer un professeur
     * 
     * @Route("/professeurs/{id}", name="delete_professeur", methods={"DELETE"})
     */
    public function delete(int $id, ProfesseurRepository $professeurRepository): JsonResponse
    {
        $professeur = $professeurRepository->find($id);

        if (!$professeur) {
            return $this->json(['message' => 'Professeur non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($professeur);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Professeur supprimé avec succès.'
        ]);
    }
}