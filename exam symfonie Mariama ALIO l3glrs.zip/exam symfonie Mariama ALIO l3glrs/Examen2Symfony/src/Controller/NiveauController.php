<?php

namespace App\Controller;

use App\Entity\Niveaux;
use App\Repository\NiveauxRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class NiveauxController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher tous les niveaux
     * 
     * @Route("/niveaux", name="app_niveaux_index", methods={"GET"})
     */
    public function index(NiveauxRepository $niveauxRepository): JsonResponse
    {
        $niveaux = $niveauxRepository->findAll();

        $data = [];
        foreach ($niveaux as $niveau) {
            $data[] = [
                'id' => $niveau->getId(),
                'nom' => $niveau->getNom(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer un niveau
     * 
     * @Route("/niveaux", name="create_niveau", methods={"POST"})
     */
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que le nom du niveau est fourni
        if (!isset($data['nom'])) {
            return $this->json(['message' => 'Le nom du niveau est requis.'], Response::HTTP_BAD_REQUEST);
        }

        $niveau = new Niveaux();
        $niveau->setNom($data['nom']);

        $this->entityManager->persist($niveau);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Niveau créé avec succès.',
            'id' => $niveau->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour un niveau existant
     * 
     * @Route("/niveaux/{id}", name="update_niveau", methods={"PUT"})
     */
    public function update(int $id, Request $request, NiveauxRepository $niveauxRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $niveau = $niveauxRepository->find($id);

        if (!$niveau) {
            return $this->json(['message' => 'Niveau non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour le nom du niveau
        if (isset($data['nom'])) {
            $niveau->setNom($data['nom']);
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Niveau mis à jour avec succès.',
            'id' => $niveau->getId()
        ]);
    }

    /**
     * Supprimer un niveau
     * 
     * @Route("/niveaux/{id}", name="delete_niveau", methods={"DELETE"})
     */
    public function delete(int $id, NiveauxRepository $niveauxRepository): JsonResponse
    {
        $niveau = $niveauxRepository->find($id);

        if (!$niveau) {
            return $this->json(['message' => 'Niveau non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($niveau);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Niveau supprimé avec succès.'
        ]);
    }
}