<?php

namespace App\Controller;

use App\Entity\CourClasses;
use App\Entity\Cours;
use App\Entity\Classe;
use App\Repository\CourClassesRepository;
use App\Repository\CoursRepository;
use App\Repository\ClasseRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class CourClassesController extends AbstractController
{
    private EntityManagerInterface $entityManager;

    // Injecter EntityManagerInterface via le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher toutes les relations entre les cours et les classes
     * 
     * @Route("/cour/classes", name="app_cour_classes", methods={"GET"})
     */
    public function index(CourClassesRepository $courClassesRepository): JsonResponse
    {
        $courClasses = $courClassesRepository->findAll();

        $data = [];
        foreach ($courClasses as $courClass) {
            $data[] = [
                'id' => $courClass->getId(),
                'cours' => $courClass->getCoursId()->map(fn($cours) => $cours->getNom())->toArray(),
                'classes' => $courClass->getClasseId()->map(fn($classe) => $classe->getNom())->toArray(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer une nouvelle relation entre un cours et une classe
     * 
     * @Route("/cour/classes", name="create_cour_classes", methods={"POST"})
     */
    public function create(Request $request, CoursRepository $coursRepository, ClasseRepository $classeRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que les données sont valides
        if (!isset($data['cours_id']) || !isset($data['classe_id'])) {
            return $this->json(['message' => 'Cours et Classe sont requis.'], Response::HTTP_BAD_REQUEST);
        }

        $cours = $coursRepository->find($data['cours_id']);
        $classe = $classeRepository->find($data['classe_id']);

        if (!$cours || !$classe) {
            return $this->json(['message' => 'Cours ou Classe non trouvés.'], Response::HTTP_NOT_FOUND);
        }

        $courClass = new CourClasses();
        $courClass->addCoursId($cours);
        $courClass->addClasseId($classe);

        // Utilisation de l'EntityManager injecté
        $this->entityManager->persist($courClass);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Relation créée avec succès.',
            'id' => $courClass->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour une relation entre un cours et une classe
     * 
     * @Route("/cour/classes/{id}", name="update_cour_classes", methods={"PUT"})
     */
    public function update(int $id, Request $request, CourClassesRepository $courClassesRepository, CoursRepository $coursRepository, ClasseRepository $classeRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $courClass = $courClassesRepository->find($id);

        if (!$courClass) {
            return $this->json(['message' => 'Relation non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        // Vérifier que les données sont valides
        if (isset($data['cours_id'])) {
            $cours = $coursRepository->find($data['cours_id']);
            if ($cours) {
                $courClass->addCoursId($cours);
            }
        }

        if (isset($data['classe_id'])) {
            $classe = $classeRepository->find($data['classe_id']);
            if ($classe) {
                $courClass->addClasseId($classe);
            }
        }

        // Utilisation de l'EntityManager injecté
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Relation mise à jour avec succès.',
            'id' => $courClass->getId()
        ]);
    }

    /**
     * Supprimer une relation entre un cours et une classe
     * 
     * @Route("/cour/classes/{id}", name="delete_cour_classes", methods={"DELETE"})
     */
    public function delete(int $id, CourClassesRepository $courClassesRepository): JsonResponse
    {
        $courClass = $courClassesRepository->find($id);

        if (!$courClass) {
            return $this->json(['message' => 'Relation non trouvée.'], Response::HTTP_NOT_FOUND);
        }

        // Utilisation de l'EntityManager injecté
        $this->entityManager->remove($courClass);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Relation supprimée avec succès.'
        ]);
    }
}