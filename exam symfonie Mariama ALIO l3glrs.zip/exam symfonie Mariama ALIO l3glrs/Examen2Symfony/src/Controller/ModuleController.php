<?php

namespace App\Controller;

use App\Entity\Module;
use App\Repository\ModuleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\ORM\EntityManagerInterface;

class ModuleController extends AbstractController
{
    private $entityManager;

    // Injection de l'EntityManager dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Afficher tous les modules
     * 
     * @Route("/module", name="app_module_index", methods={"GET"})
     */
    public function index(ModuleRepository $moduleRepository): JsonResponse
    {
        $modules = $moduleRepository->findAll();

        $data = [];
        foreach ($modules as $module) {
            $data[] = [
                'id' => $module->getId(),
                'nom' => $module->getNom(),
            ];
        }

        return $this->json($data);
    }

    /**
     * Créer un module
     * 
     * @Route("/module", name="create_module", methods={"POST"})
     */
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Vérifier que le nom du module est fourni
        if (!isset($data['nom'])) {
            return $this->json(['message' => 'Le nom du module est requis.'], Response::HTTP_BAD_REQUEST);
        }

        $module = new Module();
        $module->setNom($data['nom']);

        $this->entityManager->persist($module);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Module créé avec succès.',
            'id' => $module->getId()
        ], Response::HTTP_CREATED);
    }

    /**
     * Mettre à jour un module existant
     * 
     * @Route("/module/{id}", name="update_module", methods={"PUT"})
     */
    public function update(int $id, Request $request, ModuleRepository $moduleRepository): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $module = $moduleRepository->find($id);

        if (!$module) {
            return $this->json(['message' => 'Module non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        // Mettre à jour le nom du module
        if (isset($data['nom'])) {
            $module->setNom($data['nom']);
        }

        $this->entityManager->flush();

        return $this->json([
            'message' => 'Module mis à jour avec succès.',
            'id' => $module->getId()
        ]);
    }

    /**
     * Supprimer un module
     * 
     * @Route("/module/{id}", name="delete_module", methods={"DELETE"})
     */
    public function delete(int $id, ModuleRepository $moduleRepository): JsonResponse
    {
        $module = $moduleRepository->find($id);

        if (!$module) {
            return $this->json(['message' => 'Module non trouvé.'], Response::HTTP_NOT_FOUND);
        }

        $this->entityManager->remove($module);
        $this->entityManager->flush();

        return $this->json([
            'message' => 'Module supprimé avec succès.'
        ]);
    }
}