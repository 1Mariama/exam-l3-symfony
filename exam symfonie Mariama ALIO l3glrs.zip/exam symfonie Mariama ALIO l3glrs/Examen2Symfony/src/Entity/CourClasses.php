<?php

namespace App\Entity;

use App\Repository\CourClassesRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CourClassesRepository::class)]
class CourClasses
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    /**
     * @var Collection<int, Cours>
     */
    #[ORM\ManyToMany(targetEntity: Cours::class, inversedBy: 'courClasses')]
    private Collection $cours_id;

    /**
     * @var Collection<int, Classe>
     */
    #[ORM\ManyToMany(targetEntity: Classe::class, inversedBy: 'courClasses')]
    private Collection $classe_id;

    public function __construct()
    {
        $this->cours_id = new ArrayCollection();
        $this->classe_id = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, Cours>
     */
    public function getCoursId(): Collection
    {
        return $this->cours_id;
    }

    public function addCoursId(Cours $coursId): static
    {
        if (!$this->cours_id->contains($coursId)) {
            $this->cours_id->add($coursId);
        }

        return $this;
    }

    public function removeCoursId(Cours $coursId): static
    {
        $this->cours_id->removeElement($coursId);

        return $this;
    }

    /**
     * @return Collection<int, Classe>
     */
    public function getClasseId(): Collection
    {
        return $this->classe_id;
    }

    public function addClasseId(Classe $classeId): static
    {
        if (!$this->classe_id->contains($classeId)) {
            $this->classe_id->add($classeId);
        }

        return $this;
    }

    public function removeClasseId(Classe $classeId): static
    {
        $this->classe_id->removeElement($classeId);

        return $this;
    }
}