<?php

namespace App\Entity;

use App\Repository\ClasseRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ClasseRepository::class)]
class Classe
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;


    /**
     * @var Collection<int, Inscription>
     */
    #[ORM\OneToMany(targetEntity: Inscription::class, mappedBy: 'classe_id')]
    private Collection $inscriptions;

    /**
     * @var Collection<int, CourClasses>
     */
    #[ORM\ManyToMany(targetEntity: CourClasses::class, mappedBy: 'classe_id')]
    private Collection $courClasses;

    #[ORM\ManyToOne(inversedBy: 'classes')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Niveaux $niveau_id = null;

    public function __construct()
    {
        $this->inscriptions = new ArrayCollection();
        $this->courClasses = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, Inscription>
     */
    public function getInscriptions(): Collection
    {
        return $this->inscriptions;
    }

    public function addInscription(Inscription $inscription): static
    {
        if (!$this->inscriptions->contains($inscription)) {
            $this->inscriptions->add($inscription);
            $inscription->setClasseId($this);
        }

        return $this;
    }

    public function removeInscription(Inscription $inscription): static
    {
        if ($this->inscriptions->removeElement($inscription)) {
            // set the owning side to null (unless already changed)
            if ($inscription->getClasseId() === $this) {
                $inscription->setClasseId(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CourClasses>
     */
    public function getCourClasses(): Collection
    {
        return $this->courClasses;
    }

    public function addCourClass(CourClasses $courClass): static
    {
        if (!$this->courClasses->contains($courClass)) {
            $this->courClasses->add($courClass);
            $courClass->addClasseId($this);
        }

        return $this;
    }

    public function removeCourClass(CourClasses $courClass): static
    {
        if ($this->courClasses->removeElement($courClass)) {
            $courClass->removeClasseId($this);
        }

        return $this;
    }

    public function getNiveauId(): ?Niveaux
    {
        return $this->niveau_id;
    }

    public function setNiveauId(?Niveaux $niveau_id): static
    {
        $this->niveau_id = $niveau_id;

        return $this;
    }
}