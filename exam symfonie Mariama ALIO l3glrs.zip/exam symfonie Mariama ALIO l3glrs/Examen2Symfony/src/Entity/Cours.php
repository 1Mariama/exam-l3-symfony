<?php

namespace App\Entity;

use App\Repository\CoursRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CoursRepository::class)]
class Cours
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'cours')]
    private ?Professeur $professeur_id = null;

    #[ORM\ManyToOne(inversedBy: 'cours')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Module $module_id = null;

  

    /**
     * @var Collection<int, Session>
     */
    #[ORM\OneToMany(targetEntity: Session::class, mappedBy: 'cours_id')]
    private Collection $sessions;

    /**
     * @var Collection<int, CourClasses>
     */
    #[ORM\ManyToMany(targetEntity: CourClasses::class, mappedBy: 'cours_id')]
    private Collection $courClasses;

    public function __construct()
    {
        
        $this->sessions = new ArrayCollection();
        $this->courClasses = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getProfesseurId(): ?Professeur
    {
        return $this->professeur_id;
    }

    public function setProfesseurId(?Professeur $professeur_id): static
    {
        $this->professeur_id = $professeur_id;

        return $this;
    }

    public function getModuleId(): ?Module
    {
        return $this->module_id;
    }

    public function setModuleId(?Module $module_id): static
    {
        $this->module_id = $module_id;

        return $this;
    }

    

    /**
     * @return Collection<int, Session>
     */
    public function getSessions(): Collection
    {
        return $this->sessions;
    }

    public function addSession(Session $session): static
    {
        if (!$this->sessions->contains($session)) {
            $this->sessions->add($session);
            $session->setCoursId($this);
        }

        return $this;
    }

    public function removeSession(Session $session): static
    {
        if ($this->sessions->removeElement($session)) {
            // set the owning side to null (unless already changed)
            if ($session->getCoursId() === $this) {
                $session->setCoursId(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CourClasses>
     */
    public function getCourClasses(): Collection
    {
        return $this->courClasses;
    }

    public function addCourClass(CourClasses $courClass): static
    {
        if (!$this->courClasses->contains($courClass)) {
            $this->courClasses->add($courClass);
            $courClass->addCoursId($this);
        }

        return $this;
    }

    public function removeCourClass(CourClasses $courClass): static
    {
        if ($this->courClasses->removeElement($courClass)) {
            $courClass->removeCoursId($this);
        }

        return $this;
    }
}