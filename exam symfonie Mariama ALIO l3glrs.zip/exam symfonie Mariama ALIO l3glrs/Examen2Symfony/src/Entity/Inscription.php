<?php

namespace App\Entity;

use App\Repository\InscriptionRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: InscriptionRepository::class)]
class Inscription
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'inscriptions')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Etudiant $etudiant_id = null;

    #[ORM\ManyToOne(inversedBy: 'inscriptions')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Classe $classe_id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $annee_scolaire = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtudiantId(): ?Etudiant
    {
        return $this->etudiant_id;
    }

    public function setEtudiantId(?Etudiant $etudiant_id): static
    {
        $this->etudiant_id = $etudiant_id;

        return $this;
    }

    public function getClasseId(): ?Classe
    {
        return $this->classe_id;
    }

    public function setClasseId(?Classe $classe_id): static
    {
        $this->classe_id = $classe_id;

        return $this;
    }

    public function getAnneeScolaire(): ?\DateTimeInterface
    {
        return $this->annee_scolaire;
    }

    public function setAnneeScolaire(\DateTimeInterface $annee_scolaire): static
    {
        $this->annee_scolaire = $annee_scolaire;

        return $this;
    }
}
